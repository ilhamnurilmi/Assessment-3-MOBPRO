package com.ilhamnurilmi.todonoted.data.model

data class Todo(
    val title: String,
    var isChecked: Boolean = false
)